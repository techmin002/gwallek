<?php

return [
    'name' => 'Faq'
];

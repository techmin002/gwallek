<?php

return [
    'name' => 'Service',
];

<?php

return [
    'name' => 'OrderManager',
];

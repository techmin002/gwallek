<?php

return [
    'name' => 'Finance',
];

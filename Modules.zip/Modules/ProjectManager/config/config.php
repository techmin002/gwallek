<?php

return [
    'name' => 'ProjectManager',
];

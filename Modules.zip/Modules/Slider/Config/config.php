<?php

return [
    'name' => 'Slider'
];

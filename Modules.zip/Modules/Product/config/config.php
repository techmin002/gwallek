<?php

return [
    'name' => 'Product',
];

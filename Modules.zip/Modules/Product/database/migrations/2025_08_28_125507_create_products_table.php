<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name');
            $table->string('slug');
            $table->integer('price')->nullable();
            $table->string('brand_id');
            $table->string('branch_id')->nullable();
            $table->string('category_id');
            $table->string('unit_id')->nullable();
            $table->integer('stock')->default(0);
            $table->longText('description')->nullable();
            $table->string('image')->nullable();
            $table->text('images')->nullable();
            $table->string('status')->default('on');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
